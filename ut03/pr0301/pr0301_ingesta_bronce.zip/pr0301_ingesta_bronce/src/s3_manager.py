import json
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError

from config import BUCKET, PREFIJO_PREDICCIONES, REGION


def conectar_s3():
    s3 = boto3.client("s3", region_name=REGION)
    try:
        s3.head_bucket(Bucket=BUCKET)
    except ClientError as error:
        if error.response["ResponseMetadata"]["HTTPStatusCode"] != 404:
            raise
        opciones = {}
        if REGION != "us-east-1":
            opciones["CreateBucketConfiguration"] = {"LocationConstraint": REGION}
        try:
            s3.create_bucket(Bucket=BUCKET, **opciones)
        except s3.exceptions.BucketAlreadyOwnedByYou:
            pass
    return s3


def metadatos(fuente, instante):
    return {"source": fuente, "ingestion_timestamp": instante.strftime("%Y-%m-%dT%H:%M:%SZ")}


def subir_archivo(s3, ruta, clave, fuente):
    ahora = datetime.now(timezone.utc)
    s3.upload_file(str(ruta), BUCKET, clave, ExtraArgs={
        "ContentType": "text/csv", "Metadata": metadatos(fuente, ahora)
    })
    return clave


def subir_prediccion(s3, id_playa, prediccion):
    ahora = datetime.now(timezone.utc)
    particion = ahora.strftime("year=%Y/month=%m/day=%d")
    clave = f"{PREFIJO_PREDICCIONES}/{particion}/pred_playa_{id_playa}_{ahora:%H%M%S}.json"
    contenido = json.dumps(prediccion, ensure_ascii=False).encode("utf-8")
    s3.put_object(Bucket=BUCKET, Key=clave, Body=contenido, ContentType="application/json",
                  Metadata=metadatos("AEMET_API", ahora), IfNoneMatch="*")
    return clave
