import logging
import sys
import time

from boto3.exceptions import S3UploadFailedError
from botocore.exceptions import BotoCoreError, ClientError

import config
from aemet_client import obtener_prediccion
from catalogos import leer_catalogos, playas_de_provincia
from s3_manager import conectar_s3, subir_archivo, subir_prediccion


def main():
    faltan = config.faltan_claves_aws()
    if not config.API_KEY:
        faltan.append("AEMET_API_KEY")
    if faltan:
        logging.error("Completa el archivo .env. Faltan %s.", ", ".join(faltan))
        return 1

    catalogos_subidos = predicciones_subidas = omitidas = 0
    try:
        s3 = conectar_s3()
        for ruta, clave, fuente in [
            (config.CSV_MITECO, config.CLAVE_MITECO, "MITECO_OpenData"),
            (config.CSV_AEMET, config.CLAVE_AEMET, "AEMET_Catalogo"),
        ]:
            subir_archivo(s3, ruta, clave, fuente)
            catalogos_subidos += 1
            logging.info("Subido s3://%s/%s", config.BUCKET, clave)

        miteco, aemet = leer_catalogos()
        municipios, candidatas = playas_de_provincia(miteco, aemet, config.PROVINCIA)
        seleccion = candidatas.head(config.MAX_PLAYAS)
        logging.info("%s: %d municipios, %d playas AEMET. Se consultan %d.",
                     config.PROVINCIA, len(municipios), len(candidatas), len(seleccion))

        for numero, id_playa in enumerate(seleccion["ID_PLAYA"]):
            if numero:
                time.sleep(config.PAUSA_AEMET)
            prediccion = obtener_prediccion(id_playa)
            if prediccion is None:
                omitidas += 1
                continue
            clave = subir_prediccion(s3, id_playa, prediccion)
            predicciones_subidas += 1
            logging.info("Subido s3://%s/%s", config.BUCKET, clave)
    except (OSError, ValueError, BotoCoreError, ClientError, S3UploadFailedError) as error:
        logging.error("Se ha interrumpido la ingesta: %s", error)
        return 1
    finally:
        logging.info("Resumen: %d catálogos, %d predicciones y %d playas omitidas. "
                     "Total de archivos subidos: %d.", catalogos_subidos, predicciones_subidas,
                     omitidas, catalogos_subidos + predicciones_subidas)
    if not predicciones_subidas:
        logging.warning("No se ha subido ninguna predicción. Revisa los avisos de AEMET.")
        return 1
    return 0


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s",
                        datefmt="%Y-%m-%d %H:%M:%S")
    sys.exit(main())
