import os
from pathlib import Path

from dotenv import load_dotenv


RAIZ = Path(__file__).resolve().parents[1]
load_dotenv(RAIZ / ".env")

CSV_MITECO = RAIZ / "data" / "playas.csv"
CSV_AEMET = RAIZ / "data" / "playas_codigos.csv"
CLAVE_MITECO = "bronce/catalogos/miteco_playas/v1/playas.csv"
CLAVE_AEMET = "bronce/catalogos/aemet_codigos/v1/playas_codigos.csv"
PREFIJO_PREDICCIONES = "bronce/meteorologia/aemet_prediccion_playas"

PROVINCIA = os.getenv("PROVINCIA") or "Asturias"
MAX_PLAYAS = 15
PAUSA_AEMET = 1.5
REGION = os.getenv("AWS_DEFAULT_REGION") or "us-east-1"
BUCKET = os.getenv("S3_BUCKET_NAME") or "datalake-turismo-bronce-dbb"
API_KEY = os.getenv("AEMET_API_KEY")


def faltan_claves_aws():
    variables = ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"]
    # Las claves temporales del laboratorio de AWS necesitan también el token.
    if os.getenv("AWS_ACCESS_KEY_ID", "").startswith("ASIA"):
        variables.append("AWS_SESSION_TOKEN")
    return [nombre for nombre in variables if not os.getenv(nombre)]
