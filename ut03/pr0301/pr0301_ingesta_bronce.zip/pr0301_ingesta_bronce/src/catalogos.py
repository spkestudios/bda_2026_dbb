import pandas as pd

from config import CSV_AEMET, CSV_MITECO


def leer_catalogos():
    miteco = pd.read_csv(CSV_MITECO, sep=",", encoding="utf-8-sig",
                         dtype={"Código_IN": "string"})
    aemet = pd.read_csv(CSV_AEMET, sep=";", encoding="cp1252",
                        dtype={"ID_PLAYA": "string", "ID_MUNICIPIO": "string",
                               "ID_PROVINCIA": "string"})
    for tabla, columna, ancho in [(miteco, "Código_IN", 5), (aemet, "ID_MUNICIPIO", 5),
                                  (aemet, "ID_PLAYA", 7)]:
        codigos = tabla[columna].str.strip()
        validos = codigos.str.fullmatch(fr"[0-9]{{1,{ancho}}}", na=False)
        tabla[columna] = codigos.where(validos).str.zfill(ancho)
    return miteco, aemet


def playas_de_provincia(miteco, aemet, provincia):
    filtro = miteco["Provincia"].str.strip().str.casefold() == provincia.strip().casefold()
    municipios = set(miteco.loc[filtro, "Código_IN"].dropna())
    if not municipios:
        raise ValueError(f"No hay municipios de {provincia} en el catálogo del MITECO.")

    candidatas = aemet.loc[aemet["ID_MUNICIPIO"].isin(municipios)]
    candidatas = candidatas.dropna(subset=["ID_PLAYA"]).drop_duplicates("ID_PLAYA")
    return municipios, candidatas.sort_values("ID_PLAYA")
