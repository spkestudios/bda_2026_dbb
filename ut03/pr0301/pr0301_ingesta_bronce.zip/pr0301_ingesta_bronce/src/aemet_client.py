import json
import logging
import re
import time

import requests

from config import API_KEY, PAUSA_AEMET


URL_PLAYAS = "https://opendata.aemet.es/opendata/api/prediccion/especifica/playa"


def obtener_prediccion(id_playa):
    """Consulta la URL de control y después descarga el JSON de esa playa."""
    if not re.fullmatch(r"[0-9]{7}", id_playa):
        raise ValueError("ID_PLAYA debe tener siete dígitos.")

    try:
        respuesta = requests.get(f"{URL_PLAYAS}/{id_playa}", timeout=15,
                                 headers={"api_key": API_KEY, "Accept": "application/json"})
        respuesta.raise_for_status()
        control = respuesta.json()
        if not isinstance(control, dict):
            raise ValueError("La respuesta de control no es un objeto JSON.")
        if str(control.get("estado")) != "200" or not control.get("datos"):
            logging.warning("Playa %s: AEMET indica estado %s. Se omite.",
                            id_playa, control.get("estado"))
            return None

        time.sleep(PAUSA_AEMET)
        # El segundo salto usa una URL temporal y ya no necesita la clave.
        datos = requests.get(control["datos"], timeout=15)
        datos.raise_for_status()
        try:
            texto = datos.content.decode("utf-8-sig")
        except UnicodeDecodeError:
            texto = datos.content.decode("iso-8859-15")
        prediccion = json.loads(texto)
        if not isinstance(prediccion, (list, dict)) or not prediccion:
            raise ValueError("El JSON de predicción está vacío o tiene un formato inesperado.")
        if isinstance(prediccion, dict) and "estado" in prediccion and "prediccion" not in prediccion:
            logging.warning("Playa %s: AEMET devuelve estado %s en el segundo salto.",
                            id_playa, prediccion["estado"])
            return None
        return prediccion
    except requests.HTTPError as error:
        codigo = error.response.status_code
        logging.warning("Playa %s: HTTP %s. Se omite.", id_playa, codigo)
        espera = error.response.headers.get("Retry-After", "")
        if codigo == 429 and espera.isdecimal():
            time.sleep(int(espera))
    except requests.Timeout:
        logging.warning("Playa %s: AEMET ha tardado demasiado en responder.", id_playa)
    except requests.ConnectionError:
        logging.warning("Playa %s: no se ha podido conectar con AEMET.", id_playa)
    except (requests.RequestException, ValueError) as error:
        logging.warning("Playa %s: respuesta de AEMET no disponible (%s).",
                        id_playa, type(error).__name__)
    return None
